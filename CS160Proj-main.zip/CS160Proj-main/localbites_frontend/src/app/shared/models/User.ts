export class User{
    user_id!:number;
    name!:string;
    email!:string;
    zip_code!:string;
    password!:string;
    wallet!:number;
}