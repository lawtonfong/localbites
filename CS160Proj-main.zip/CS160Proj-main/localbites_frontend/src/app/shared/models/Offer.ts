export class Offer{
    id!:number;
    user_name!:string;
    restaurant!:string;
    discount!:number;
    location!:string;
    zipcode!:string;
    name: any;
}