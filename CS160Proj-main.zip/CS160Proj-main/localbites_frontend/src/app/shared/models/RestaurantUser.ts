export class RestaurantUser{
    user_id!:number;
    name!:string;
    email!:string;
    password!:string;
}