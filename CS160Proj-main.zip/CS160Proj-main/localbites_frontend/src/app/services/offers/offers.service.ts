// import { Injectable } from '@angular/core';
// import {Offer} from '../../shared/models/Offer';
// @Injectable({
//   providedIn: 'root'
// })
// export class OffersService {

//   constructor() { }

//   getAll():Offer[]{
//     return [
//       {
//         id:1,
//         user_name:"The Burger Dude",
//         restaurant: "Burger King",
//         discount: 10,
//         location: "15478 Burger Lane, 95030",
//         zipcode: "12345"
//       },
//       {
//         id:2,
//         user_name:"The Chicken Dude",
//         restaurant: "KFC",
//         discount: 15,
//         location: "25718 Chicken Lane, 95030",
//         zipcode: "45678"
//       }
//     ]
//   }
// }

// // export class Offer{
// //   id!:number;
// //   user_name!:string;
// //   restaurant!:string;
// //   location!:string;
// // }