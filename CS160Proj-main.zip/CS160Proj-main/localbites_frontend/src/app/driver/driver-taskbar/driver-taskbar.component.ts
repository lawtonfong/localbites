import { Component } from '@angular/core';

@Component({
  selector: 'app-driver-taskbar',
  templateUrl: './driver-taskbar.component.html',
  styleUrl: './driver-taskbar.component.css'
})
export class DriverTaskbarComponent {

}
